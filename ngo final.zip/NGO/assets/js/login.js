//login form validation

function Login(){
    //email validation
    if(!validate())
    {
      return;
    }
    else{
      alert("form is successfully submitted");
    }
  }
  function validate()
  {
    const emailv=document.getElementById("email");
    const emailip=emailv.value;
  
    const erroremail=document.getElementsByClassName("emailerror");
    const emailregex=/^[^/s@]+@[^/s@]+\.[^/s@]+$/;
  
    if(!(emailregex.test(emailip)))
    {
      emailv.style.border="2px solid red";
      erroremail.style.display="block";
      return false;
    }
    else{
      emailv.style.border="";
      erroremail.style.display="none";
    }
    
  
    //validation for phone number
    const phone=document.getElementById("phoneno");
    const phonev=phone.value;
    const  phoneerror=document.getElementsByClassName("phoneerror");
  
    const phoneregex=/^[0-9{10}$]/;
    if(!phoneregex.test(phonev)){
      phone.style.border="2px solid red";
      phoneerror.style.display="block";
      return false;
    }
    else{
      phone.style.border="";
      phoneerror.style.display="none";
    }
  
    const pass=document.getElementById("pass");
    const passip=pass.value;
  
    const passerror=document.getElementsByClassName("passerror");

     var passwordPattern = /^(?=.*\d)(?=.*[a-zA-Z]).{6,}$/;
     
     if(!passwordPattern.test(passip))
     {
      pass.style.border="2px solid red";
      passerror.style.display="block";
      return false;
    }
    else{
      pass.style.border="";
      passerror.style.display="none";
    }
   
  
    return true;
  }

 