var xValues = ["Education", "Health", "Money", "Food", "Cloths"];
var yValues = [55, 49, 44, 24, 15];
var barColors = [
  "rgb(247, 150, 242)",
  "rgb(150, 181, 247)",
  "rgb(153, 151, 149)",
  "rgb(128, 252, 180)",
  "rgb(255, 245, 105)"
];

new Chart("myChart", {
  type: "doughnut",
  data: {
    labels: xValues,
    datasets: [{
      backgroundColor: barColors,
      data: yValues
    }]
  },
  options: {
    title: {
      display: true,
      text: "Donation in Each Sector Pie Chart"
    }
  }
});



// // Initial rendering of the chart
// var myChart = new Chart("myChart", {
//   type: "doughnut",
//   data: {
//     labels: xValues,
//     datasets: [{
//       backgroundColor: barColors,
//       data: yValues
//     }]
//   },
//   options: {
//     legend: { display: false },
//     title: {
//       display: true,
//       text: "Donation in Each Sector Pie Chart"
//     }
//   }
// });

// // Function to rotate the chart
// function rotateChart() {
//   // Remove the first element from xValuesb and yValuesb arrays
//   var removedXValue = xValues.shift();
//   var removedYValue = yValues.shift();

//   // Push the removed elements to the end of the arrays
//   xValues.push(removedXValue);
//   yValues.push(removedYValue);

//   // Update the chart data
//   myChart.data.labels = xValues;
//   myChart.data.datasets[0].data = yValues;
//   myChart.update();
// }

// // Rotate the chart every 30 seconds (30000 milliseconds)
// setInterval(rotateChart, 3000);
















var xValuesb = ["Education", "Health", "Money", "Food", "Cloths"];
var yValuesb = [55, 49, 44, 24, 15];
var barColorsb = ["red", "green","blue","orange","brown"];

new Chart("mybarChart", {
  type: "bar",
  data: {
    labels: xValuesb,
    datasets: [{
      backgroundColor: barColorsb,
      data: yValuesb
    }]
  },
  options: {
    legend: {display: false},
    title: {
      display: true,
      text: "Bar Graph"
    }
  }
});





