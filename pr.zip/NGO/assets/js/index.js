var xValues = ["Education", "Health", "Money", "Food", "Cloths"];
var yValues = [55, 49, 44, 24, 15];
var barColors = [
  "rgb(247, 150, 242)",
  "rgb(150, 181, 247)",
  "rgb(153, 151, 149)",
  "rgb(128, 252, 180)",
  "rgb(255, 245, 105)"
];

new Chart("myChart", {
  type: "doughnut",
  data: {
    labels: xValues,
    datasets: [{
      backgroundColor: barColors,
      data: yValues
    }]
  },
  options: {
    title: {
      display: true,
      text: "Donation in Each Sector Pie Chart"
    }
  }
});



// // Initial rendering of the chart
// var myChart = new Chart("myChart", {
//   type: "doughnut",
//   data: {
//     labels: xValues,
//     datasets: [{
//       backgroundColor: barColors,
//       data: yValues
//     }]
//   },
//   options: {
//     legend: { display: false },
//     title: {
//       display: true,
//       text: "Donation in Each Sector Pie Chart"
//     }
//   }
// });

// // Function to rotate the chart
// function rotateChart() {
//   // Remove the first element from xValuesb and yValuesb arrays
//   var removedXValue = xValues.shift();
//   var removedYValue = yValues.shift();

//   // Push the removed elements to the end of the arrays
//   xValues.push(removedXValue);
//   yValues.push(removedYValue);

//   // Update the chart data
//   myChart.data.labels = xValues;
//   myChart.data.datasets[0].data = yValues;
//   myChart.update();
// }

// // Rotate the chart every 30 seconds (30000 milliseconds)
// setInterval(rotateChart, 3000);



var xValuesb = ["Education", "Health", "Money", "Food", "Cloths"];
var yValuesb = [55, 49, 44, 24, 15];
var barColorsb = ["red", "green","blue","orange","brown"];

new Chart("mybarChart", {
  type: "bar",
  data: {
    labels: xValuesb,
    datasets: [{
      backgroundColor: barColorsb,
      data: yValuesb
    }]
  },
  options: {
    legend: {display: false},
    title: {
      display: true,
      text: "Bar Graph"
    }
  }
});


//login form validation

function Login(){
  //email validation
  if(!validate())
  {
    return false;
  }
  else{
    alert("form is successfully submitted");


  document.getElementById("email").value="";
  document.getElementById("phoneno").value="";
  document.getElementById("pass").value="";

    return true;
   
  }
}
function validate()
{
  const emailv=document.getElementById("email");
  const emailip=emailv.value;

  const erroremail=document.getElementById("emailerror");
  const emailregex=/^[^/s@]+@[^/s@]+\.[^/s@]+$/;

  if(!(emailregex.test(emailip)))
  {
    emailv.style.border="2px solid red";
    erroremail.style.display="block";
    return false;
  }
  else{
    emailv.style.border="";
    erroremail.style.display="none";
  }
  

  //validation for phone number
  const phone=document.getElementById("phoneno");
  const phonev=phone.value;
  const  phoneerror=document.getElementById("phoneerror");

  const phoneregex=/^\d{10}$/;



  if(!phoneregex.test(phonev)){
    phone.style.border="2px solid red";
    phoneerror.style.display="block";
    return false;
  }

  else{
    phone.style.border="";
    phoneerror.style.display="none";
  }

  const pass=document.getElementById("pass");
  const passip=pass.value;

  const passerror=document.getElementById("passerror");

   var passwordPattern = /^(?=.*\d)(?=.*[a-zA-Z])(?=.*[!@#$%^&*()\-_=+{};:,<.>]).{6,}$/;
  

   
   if(!passwordPattern.test(passip))
   {
    pass.style.border="2px solid red";
    passerror.style.display="block";
    return false;
  }
  else{
    pass.style.border="";
    passerror.style.display="none";
  }
 

  return true;
}


var modalId = document.getElementById('modalId');

  modalId.addEventListener('show.bs.modal', function (event) {
      // Button that triggered the modal
      let button = event.relatedTarget;
      // Extract info from data-bs-* attributes
      let recipient = button.getAttribute('data-bs-whatever');

    // Use above variables to manipulate the DOM
  });

  function Registration()
  {
    if(!validatereg())
    {
      return false;
    }
    else{
      alert("registration is successfull ");
  
  
    document.getElementById("ngonm").value="";
    document.getElementById("email1").value="";
    document.getElementById("phoneno1").value="";
    document.getElementById("pass1").value="";
      return true;
     
    }
  }

  function validatereg()
  {
   
    const ngonm=document.getElementById("ngonm");
    const ngoip=ngonm.value;

    const ngoregex=/^[a-zA-Z]+$/;
    const ngonmerror=document.getElementById("ngonmerror");

    if(!(ngoregex.test(ngoip)))
    {
      ngonm.style.border="2px solid red";
      ngonmerror.style.display="block";
    return false;
  }
  else{
    ngonm.style.border="";
    ngonmerror.style.display="none";
  }


  const emailv1=document.getElementById("email1");
  const emailip1=emailv1.value;

  const erroremail1=document.getElementById("emailerror1");
  const emailregex1=/^[^/s@]+@[^/s@]+\.[^/s@]+$/;

  if(!(emailregex1.test(emailip1)))
  {
    emailv1.style.border="2px solid red";
    erroremail1.style.display="block";
    return false;
  }
  else{
    emailv1.style.border="";
    erroremail1.style.display="none";
  }
  

  //validation for phone number
  const phone1=document.getElementById("phoneno1");
  const phonev1=phone1.value;
  const  phoneerror1=document.getElementById("phoneerror1");

  const phoneregex1=/^\d{10}$/;



  if(!phoneregex1.test(phonev1)){
    phone1.style.border="2px solid red";
    phoneerror1.style.display="block";
    return false;
  }

  else{
    phone1.style.border="";
    phoneerror1.style.display="none";
  }

  const pass1=document.getElementById("pass1");
  const passip1=pass1.value;

  const passerror1=document.getElementById("passerror1");

   var passwordPattern1 = /^(?=.*\d)(?=.*[a-zA-Z])(?=.*[!@#$%^&*()\-_=+{};:,<.>]).{6,}$/;
  

   
   if(!passwordPattern1.test(passip1))
   {
    pass1.style.border="2px solid red";
    passerror1.style.display="block";
    return false;
  }
  else{
    pass1.style.border="";
    passerror1.style.display="none";
  }
 
  return true;
  }


  function openRegistrationModal() {

    var registrationModal = new bootstrap.Modal(document.getElementById('modalId1'));
    registrationModal.show();

  }

  function forget() {
    // Generate unique ID for the modal
    var modalId = "modalId_" + new Date().getTime(); // You can use a more robust method for generating unique IDs if needed

    // Create the forget password modal
    var forgetrow = document.createElement("form");
    forgetrow.innerHTML = `
    <div
      class="modal fade"
      id="${modalId}"
      tabindex="-1"
      role="dialog"
      aria-labelledby="modalTitleId"
      aria-hidden="true"
    >
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="modalTitleId">
              Forget Password
            </h5>
            <button
              type="button"
              class="btn-close"
              data-bs-dismiss="modal"
              aria-label="Close"
            ></button>
          </div>
          <div class="modal-body">
            <div class="container-fluid">
              <div class="col">
                <label for="${modalId}_email">Email Id</label>
                <input type="email" placeholder="abc@gmail.com" id="${modalId}_email" class="form-control" >
                <div id="${modalId}_emailerror" style="display: none; color: red;">Please enter valid email</div>
              </div>
              <div class="col">
                <label for="${modalId}_phoneno">Phone Number</label>
                <input type="number" id="${modalId}_phoneno" class="form-control" required>
                <div id="${modalId}_phoneerror" style="display: none; color: red;">Only 10 Digits are allow</div>
              </div>
              <div class="col">
                <label for="${modalId}_pass">Password</label>
                <input type="text" id="${modalId}_pass" class="form-control">
                <div id="${modalId}_passerror" style="display: none; color: red;">Contain at least one character,at least one symbol and 6 length</div>
              </div>
            </div>
          </div>
          <div class="modal-footer">
            <button
              type="button"
              class="btn btn-secondary"
              data-bs-dismiss="modal"
            >
              Close
            </button>
            <button type="button" class="btn btn-primary">Set Password</button>
          </div>
        </div>
      </div>
    </div>`;

    // Append the modal to the DOM
    document.body.appendChild(forgetrow);

    // Show the modal
    var modal = new bootstrap.Modal(document.getElementById(modalId));
    modal.show();

}


