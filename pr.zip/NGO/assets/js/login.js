//login form validation

function Donation(){
    //email validation
    if(!validate3())
    {
      return;
    }
    else{
      alert("form is successfully submitted");
    }
  }
  function validate3()
  {


  //for amount validation
  const amount=document.getElementById("amount");
  const amountip=amount.value;
  const amounterror=document.getElementById("amounterror");

  const regexamount=/^[0-9]+$/;
  if(!regexamount.test(amountip))
  {
    amount.style.border="2px solid red";
    amounterror.style.display="block";
    return false;
  }
  else{
    amount.style.border="";
    amounterror.style.display="none";
  }


  //donar name validation
  const donarnm=document.getElementById("donarnm");
  const donarip=donarnm.value;
  const donarregex=document.getElementById("donarnmerror");
  const donarnmregex=/^[a-zA-Z]+$/;

  if(!donarnmregex.test(donarip))
  {
    donarnm.style.border="2px solid red";
    donarregex.style.display="block";
    return false;
  }
  else{
    donarnm.style.border="";
    donarregex.style.display="none";
  }

  //contact number
  const contact=document.getElementById("amount");
  const contactip=contact.value;
  const contacterror=document.getElementById("contacterror");

  const regexcontact=/^[0-9]+$/;
  if(!regexcontact.test(contactip))
  {
    contact.style.border="2px solid red";
    contacterror.style.display="block";
    return false;
  }
  else{
    contact.style.border="";
    contacterror.style.display="none";
  }


    const emailv=document.getElementById("emailda");
    const emailip=emailv.value;
  
    const emailerror=document.getElementsByClassName("emailerror");
    const emailregex=/^[^/s@]+@[^/s@]+\.[^/s@]+$/;
  
    if(!(emailregex.test(emailip)))
    {
      emailv.style.border="2px solid red";
      emailerror.style.display="block";
      return false;
    }
    else{
      emailv.style.border="";
      emailerror.style.display="none";
    }
    
  
    //validation for phone number
    const pin=document.getElementById("pin");
    const pinv=phone.value;
    const  pinerror=document.getElementsByClassName("pinerror");
  
    const pinregex=/^[0-9{6}$]/;
    if(!pinregex.test(pinv)){
      pin.style.border="2px solid red";
      pinerror.style.display="block";
      return false;
    }
    else{
      pin.style.border="";
      pinerror.style.display="none";
    }
  

   
  
    return true;
  }



  document.getElementById("state").addEventListener("change",function(){
    
    var state = this.value;
    var cityDropdown = document.getElementById("city");
    cityDropdown.innerHTML = ""; // Clear existing options
    
    // Populate cities based on selected state
    if (state === "Maharashra") {
      var MaharashtraCities = ["Pune", "Mumbai", "Nashik","Nagpur"];
      MaharashtraCities.forEach(function(City) {
        var option = document.createElement("option");
        option.text = City;
        option.value = City; 
        cityDropdown.add(option);
      });
    } 
    else if(state==="Gujarat")
    {
        var guajaratcities=["ambli","Jamnagar","Bopal","Vadodara"];
        guajaratcities.forEach(function(City)
    {
        var option=document.createElement("option");
        option.text=City;
        option.value=City;
        cityDropdown.add(option);
    });
    }
    else{
        var panjabcities=["Amrutsar","Ludiyana","delhi"];
        panjabcities.forEach(function(City){
            var option=document.createElement("option");
            option.text=City;
            option.value=City;
            cityDropdown.add(option);
        });
    }
  
  });
 