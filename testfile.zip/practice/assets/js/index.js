$(document).ready(function(){

    $("#datatable").DataTable();
    
   $("#itemform").click(function()
   {
    $(this).hide();
   });

   $("#datatable").click(function()
   {
    $("#itemform").toggle();
   })

})


function submitinfo(){

var categoryname1=document.getElementById("categoryname").value;
var categorydesc1=document.getElementById("categorydesc").value;
var active1=document.getElementById("active").value;
var launchdate1=document.getElementById("launchdate").value;

// if(categoryname1==""||categorydesc1==""||active1==""||launchdate1=="")
// {
//     alert("please fill info first");
// }
//validation for food items table
//var currentDate=new Date();
var valid=true;

if(!/^[a-zA-Z]+$/.test(categoryname1))
{
    alert("Category should contain only alphabetical characters");
    valid=false;
}
if(!/^[a-zA-Z]+$/.test(categorydesc1))
{
    alert("Category description should contain only alphabetical characters");
    valid=false;
}

// var sevenDaysAgo = new Date();
//     sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
//     if (launchdate1 > currentDate || launchdate1 < sevenDaysAgo) {
//         alert("Launch Date should be within the past 7 days.");
//         valid = false;
//     }

    if (valid) {
        alert("Form submitted successfully.");
       
    }

const list=document.querySelector("#list");
const row=document.createElement("tr");

row.innerHTML=`<td>${categoryname1}</td>
               <td>${categorydesc1}</td>
               <td>${active1}</td>
               <td>${launchdate1}</td>
               <td><button class='btn btn-primary' onclick='editdata(this)'>Edit</button>
               <button class='btn btn-danger' onclick='removedate(this)'>delete</button></td>`;
        
list.appendChild(row);
 
document.getElementById("categoryname").value=" ";
document.getElementById("categorydesc").value="";
document.getElementById("active").value="";
document.getElementById("launchdate").value="";



/*item table*/

var number=document.getElementById("Number").value;
var itemname=document.getElementById("itemname").value;
var itemdesc=document.getElementById("itemdesc").value;
var foodtype=document.getElementById("foodtype").value;
var price=document.getElementById("price").value;
var discount=document.getElementById("discount").value;
var discountprice=document.getElementById("discountprice").value;
var activeitem=document.getElementById("activeitem").value;



// validations

if(!/^[a-zA-Z]+$/.test(itemname))
{
    alert("item name should contain only alphabetical characters");
    valid=false;
}

if(!/^[ A-Za-z0-9_@./#&+-]*$/.test(itemdesc))
{
    alert("also contain alphanumeric value")
    valid=false
}

const itemslist=document.querySelector("#itemslist");
const row1=document.createElement("tr");

row1.innerHTML=`<td>${number}</td>
               <td>${itemname}</td>
               <td>${itemdesc}</td>
               <td>${foodtype}</td>
               <td>${price}</td>
               <td>${discount}</td>
               <td>${discountprice}</td>
               <td>${activeitem}</td>
               <td><button class='btn btn-primary' onclick='edititems(this)'>Edit</button>
               <button class='btn btn-danger' onclick='removeitems(this)'>delete</button></td>`;
               
               itemslist.appendChild(row1);
document.getElementById("Number").value="";
document.getElementById("itemname").value="";
document.getElementById("itemdesc").value="";
document.getElementById("foodtype").value="";
document.getElementById("price").value="";
document.getElementById("discount").value="";
document.getElementById("discountprice").value=""
document.getElementById("activeitem").value="";
}

function editdata(button)
{
    let newrow=button.parentNode.parentNode;

    let namecell=newrow.cells[0];
    let desccell=newrow.cells[1];
    let activecell=newrow.cells[2];
    let datecell=newrow.cells[3];

    let namecategory=prompt("enter the category name",namecell.innerHTML);
    let desccategory=prompt("enter the category description",desccell.innerHTML);
    let activecategory=prompt("enter the category status",activecell.innerHTML);
    let datcategory=prompt("enter the category date",datecell.innerHTML);

    namecell.innerHTML=namecategory;
    desccell.innerHTML=desccategory;
    activecell.innerHTML=activecategory;
    datecell.innerHTML=datcategory;

}

function removedate(button)
{
    let removerow=button.parentNode.parentNode;
    removerow.parentNode.removeChild(removerow);
}

function edititems(button)
{
    let newrowadd=button.parentNode.parentNode;

    let numbercell=newrowadd.cells[0];
    let itemnamecell=newrowadd.cells[1];
    let itemdesc=newrowadd.cells[2]
    let foodtypecell=newrowadd.cells[3];
    let pricecell=newrowadd.cells[4];
    let discountcell=newrowadd.cells[5];
    let discountpricecell=newrowadd.cells[6];
    let activeitem=newrowadd.cells[7];

    let numbercategory=prompt("enter the category number",numbercell.innerHTML);
    let itemnamecategory=prompt("enter the category item name",itemnamecell.innerHTML);
    let itemdesccategory=prompt("enter the item description",itemdesc.innerHTML);
    let foodtypecategory=prompt("enter the category status",foodtypecell.innerHTML);
    let pricecategory=prompt("enter the category price",pricecell.innerHTML);
    let discountcategory=prompt("enter the category discount",discountcell.innerHTML);
    let discountpricecategory=prompt("enter the category dicount price",discountpricecell.innerHTML);
    let activeitemcategory=prompt("check the status",activeitem.innerHTML);

    numbercell.innerHTML= numbercategory;
    itemnamecell.innerHTML=itemnamecategory;
    itemdesc.innerHTML=itemdesccategory;
    foodtypecell.innerHTML=foodtypecategory;
    pricecell.innerHTML=pricecategory;
    discountcell.innerHTML=discountcategory;
    discountpricecell.innerHTML=discountpricecategory;
    activeitem.innerHTML=activeitemcategory;
}

function removeitems(button)
{
    let removerowdel=button.parentNode.parentNode;
    removerowdel.parentNode.removeChild(removerowdel);
}






var modalId = document.getElementById('modalId');

modalId.addEventListener('show.bs.modal', function (event) {
      // Button that triggered the modal
      let button = event.relatedTarget;
      // Extract info from data-bs-* attributes
      let recipient = button.getAttribute('data-bs-whatever');

    // Use above variables to manipulate the DOM
});